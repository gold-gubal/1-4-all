package com.example.noapi.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.noapi.model.Emodel;

public interface Erepo extends CrudRepository<Emodel, Integer>{

}
