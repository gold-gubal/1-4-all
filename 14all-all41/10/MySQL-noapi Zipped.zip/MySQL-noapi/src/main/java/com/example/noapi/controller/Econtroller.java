package com.example.noapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.noapi.model.Emodel;
import com.example.noapi.repository.Erepo;

@Controller
public class Econtroller {
	
	@Autowired
	Erepo erepo;

	@RequestMapping("index")
	public String index()
	{
		return "index.jsp";
	}
	
	@RequestMapping("addemp")
	public String addemp(Emodel emodel)
	{
		erepo.save(emodel);
		return "index.jsp";
	}
	
	@RequestMapping("getemp")
	public ModelAndView getemp(@RequestParam int id)
	{
		ModelAndView mv = new ModelAndView("display.jsp");
		Emodel emodel = erepo.findById(id).orElse(new Emodel());
		mv.addObject(emodel);
		return mv;
	}
	
	@RequestMapping("deleteemp")
	public ModelAndView deleteemp(@RequestParam int id)
	{
		ModelAndView mv = new ModelAndView("delete.jsp");
		Emodel emodel = erepo.findById(id).orElse(new Emodel());
		erepo.deleteById(id);
		mv.addObject(emodel);
		return mv;
	}
	@RequestMapping("updateemp")
	public ModelAndView updateemp(Emodel emodel)
	{
		ModelAndView mv = new ModelAndView("update.jsp");
		emodel = erepo.findById(emodel.getId()).orElse(new Emodel());
		mv.addObject(emodel);
		return mv;
	}
}
