package com.example.noapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.noapi.model.Smodel;
import com.example.noapi.repository.Srepo;

@Controller
public class Scontroller {
	
	@Autowired
	Srepo srepo;
	
	@RequestMapping("index")
	public String index()
	{
		return "index.jsp";
	}
	
	@RequestMapping("addstd")
	public String addstd(Smodel smodel)
	{
		srepo.save(smodel);
		return "index.jsp";
	}

	@RequestMapping("displaystd")
	public ModelAndView displaystd(@RequestParam int id)
	{
		ModelAndView mv = new ModelAndView("display.jsp");
		Smodel smodel = srepo.findById(id).orElse(new Smodel());
		mv.addObject(smodel);
		return mv;
	}
	
	@RequestMapping("deletestd")
	public ModelAndView deletestd(@RequestParam int id)
	{
		ModelAndView mv = new ModelAndView("delete.jsp");
		Smodel smodel = srepo.findById(id).orElse(new Smodel());
		srepo.deleteById(id);
		mv.addObject(smodel);
		return mv;
	}
	
	@RequestMapping("updatestd")
	public ModelAndView updatestd(Smodel smodel)
	{
		ModelAndView mv = new ModelAndView("update.jsp");
		smodel = srepo.findById(smodel.getId()).orElse(new Smodel());
		mv.addObject(smodel);
		return mv;
	}
	
}







