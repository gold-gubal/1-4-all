package com.example.noapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoNoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoNoApiApplication.class, args);
	}

}
