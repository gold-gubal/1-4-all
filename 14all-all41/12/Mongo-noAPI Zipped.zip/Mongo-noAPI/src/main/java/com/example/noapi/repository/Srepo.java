package com.example.noapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.noapi.model.Smodel;

public interface Srepo extends MongoRepository<Smodel, Integer> {

}
