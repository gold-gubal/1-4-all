package com.example.noapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoNoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
