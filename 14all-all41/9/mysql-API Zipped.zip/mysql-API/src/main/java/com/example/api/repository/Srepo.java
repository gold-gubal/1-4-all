package com.example.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.example.api.model.Smodel;

public interface Srepo extends JpaRepository<Smodel, Integer> {

}
