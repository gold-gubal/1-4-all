package com.example.api.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.api.model.Smodel;
import com.example.api.repository.Srepo;

@RestController
public class Scontroller {
	
	@Autowired
	Srepo srepo;
	
	@GetMapping("/getstd")
	public List<Smodel> getstd()
	{
		return (List<Smodel>) srepo.findAll();
	}
	
	@GetMapping("/search/{id}")
	public Optional<Smodel> search(@PathVariable int id)
	{
		return srepo.findById(id);
	}

	@PostMapping("/addstd")
	public String addstd(@RequestBody Smodel smodel)
	{
		srepo.save(smodel);
		return "Sucessfully Added";
	}
	
	@DeleteMapping("/deletestd/{id}")
	public String deletestd(@PathVariable int id)
	{
		srepo.deleteById(id);
		return "Deleted Successfully of the id " + id;
	}
	
	@PutMapping("/updatestd")
	public String updatestd(@RequestBody Smodel smodel)
	{
		Smodel thej=srepo.findById(smodel.getId()).get();
		thej.setName(smodel.getName());
		srepo.save(thej);
		return "Updated by the id " + smodel.getId();
	}
	
}






