package com.example.api;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.api.model.Smodel;
import com.example.api.repository.Srepo;

@SpringBootTest
class MysqlApiApplicationTests {

	@Autowired
	Srepo srepo;
	
	@Test
	public void testCreate()
	{
		Smodel s = new Smodel();
		s.setId(2);
		s.setName("Rishab");
		srepo.save(s);
	}
	
	@Test
	public void testReadAll()
	{
		List<Smodel> list = srepo.findAll();
	}
	
	@Test
	public void testUpdate()
	{
		Smodel s = srepo.findById(1).get();
		s.setName("CHESS");
		srepo.save(s);
	}
	
	@Test
	public void testDelete()
	{
		srepo.deleteById(3);
	}
	
}







