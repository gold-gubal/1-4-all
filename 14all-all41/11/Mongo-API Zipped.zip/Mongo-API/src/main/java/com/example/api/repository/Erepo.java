package com.example.api.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.api.model.Emodel;

public interface Erepo extends MongoRepository<Emodel, Integer> {

}
