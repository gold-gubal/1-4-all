package com.example.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.api.model.Emodel;
import com.example.api.repository.Erepo;

@RestController
public class Econtroller {
	
	@Autowired
	Erepo erepo;
	
	@PostMapping("/addemp")
	public String addemp(@RequestBody Emodel emodel)
	{
		erepo.save(emodel);
		return "Added Successfully";
	}

	@GetMapping("/getemp")
	public List<Emodel> getemp()
	{
		return erepo.findAll();
	}
	
	@DeleteMapping("/deleteemp/{id}")
	public String deleteemp(@PathVariable int id)
	{
		erepo.deleteById(id);
		return "Successfully Deleted";
	}
	
	@PutMapping("/updateemp/{id}")
	public String updateemp()
	{
		
		return "Updated Sucessfully";
	}
	
}







